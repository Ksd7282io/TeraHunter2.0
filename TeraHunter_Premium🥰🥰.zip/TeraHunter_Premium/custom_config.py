BOTTOKEN = "6530683899:AAGBBNXyTpU4dGLEP8EX_-F6XsoLNOCDdVQ"
TG_BASE_URL =  "http://localhost:8081/bot"     #https://api.telegram.org/bot or cutsom url
DBFILE = "txbot.db"
LOGFILE = "txbot.log"
TRANSFERLOGFILE = "transfers.log"
DOWNLOADSDIRECTORY = "downloads"
COOKIE_DICT = {
    "browserid": "YNGZlwkTrHPXTywnY2aiAHPVMl9KXxoktnB7OL-nqqF_kJ--Zcj3ZWLqCUs=",
    "TSID": "WpxCW8ORGFINoUmEbolkovh66k6fvyhO",
    "_gcl_au": "1.1.759251533.1695644809",
    "__bid_n": "18acc4e76b5cf5ec574207",
    "_fbp": "fb.1.1695644809670.1814794353",
    "_ga": "GA1.1.853248366.1695644810",
    "g_state": '{"i_l": 0}',
    "dom3ic8zudi28v8lr6fgphwffqoz0j6c": "e06e57df-51c1-4966-b02d-f41bc24e8ae0%3A3%3A1",
    "ndus": "YbXI88pteHuiw09ZGfpmgS0zron_gIxYzUL-k15E",
    "ndut_fmt": "A6DC67AA12CBDB0989C6CC17A2ED894CF14A69EDD6B19734A4C7C19CC2AC930A",
    "_ga_RSNVN63CM3": "GS1.1.1695700634.4.1.1695701477.35.0.0",
    "ppu_main_9317b876caf43750c11c53a69879ded3": "1",
    "ppu_idelay_9317b876caf43750c11c53a69879ded3": "1",
    "ppu_main_82c142afcf8c96f7a1e0ef617b8db635": "1",
    "ppu_idelay_82c142afcf8c96f7a1e0ef617b8db635": "1",
    "ppu_main_9ff567c86346fd89ab457fb44f38e4de": "1" ,
    "ppu_sub_9317b876caf43750c11c53a69879ded3" : 	"2"  ,
    "ppu_sub_82c142afcf8c96f7a1e0ef617b8db635" : "2",
    "ppu_sub_9ff567c86346fd89ab457fb44f38e4de" : "2"


 }