import string
import subprocess 







# ngrokkalink


url = "http://localhost:8081/bot6530683899:AAGBBNXyTpU4dGLEP8EX_-F6XsoLNOCDdVQ/setWebhook?url=http://localhost:5000/api/telegram"




    
# Construct the termux-open command.
command = f'termux-open-url {url}'


try:
    # Execute the termux-open command.
    subprocess.run(command, shell=True, check=True)
except subprocess.CalledProcessError as e:
    print(f"Error executing termux-open: {e}")        